#!/bin/bash
echo "Аргументы"
for a in $@
do echo $a
done
