file 2
adios
o
